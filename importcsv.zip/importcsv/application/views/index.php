<!DOCTYPE html>
<html>
<head>
	<title>Import CSV</title>
  <meta charset="utf-8">
  	  <meta name="viewport" content="width=device-width, initial-scale=1">
  	  <!-- Bootstrap Link -->
  	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 	  <!-- DataTables Lib -->
      <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
      <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
      <link rel="stylesheet"  href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

</head>
<body>
	<div class="container">
		<h4 class="text-center">IMPORT CSV</h4>

		<div class="row mt-5">
	    <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php } if(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
			  <form enctype="multipart/form-data" method="post" role="form" action="<?php echo base_url('Index/import') ?>">
             <div class="col-md-4">
                     <label for="exampleInputFile">File Upload</label>
                     <input type="file" name="file" accept=".csv" required>
                      <h6>Only CSV File of report data Import.</h6>
                </div>
                <div class="col-md-4 mt-4">  
                  <button type="submit" class="btn btn-primary" name="Import" value="Import" id="Import"><i class="fa fa-upload" aria-hidden="true"></i> &nbsp;Upload</button>
                </div>
            </form>
		</div>

	<div class="card-body table-responsive">
        <table id="example" class="display nowrap table table-bordered table-hover" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Course Name</th>
                    <th>Course Code</th>
                    <th>Course Info</th>
              
                </tr>
            </thead>
            <tbody>
          <?php
          // print_r($course_info);die();
          if(empty($course_info)){
            echo '';
          }else{
             foreach ($course_info as $info) {
            echo '<tr>';
            echo '<td>'.$info['id'].'</td>';
            echo '<td>'.$info['course_name'].'</td>';
            echo '<td>'.$info['course_code'].'</td>';
            echo '<td>'.$info['course_info'].'</td>';
            echo '</tr>';
          }
          }
         
           ?>
            </tbody>
        </table>
    </div>
	</div>
<script> 
		$(document).ready(function(){
			var dataTables = $('#example').DataTable({
               				
			});
		});
	</script>

</body>
</html>
